hi. this is the most recent patch including a working master server.

changelog:
- edited master server in the .exe lol
- that's it :3

!! IMPORTANT FOR SERVER OWNERS !!
IF YOU HOST SERVERS, PLEASE MAKE SURE TO USE THIS EXE.
WITHOUT THIS EXE, YOUR SERVER WILL NOT SHOW UP ON THE INGAME BROWSER.